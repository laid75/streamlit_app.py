import streamlit as st
from transformers import AutoModelForQuestionAnswering, AutoTokenizer, pipeline
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from fpdf import FPDF
import os

# تحميل نموذج الذكاء الاصطناعي
model_name = "distilbert-base-uncased-distilled-squad"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForQuestionAnswering.from_pretrained(model_name)
qa_pipeline = pipeline("question-answering", model=model, tokenizer=tokenizer)

# إعداد صفحة Streamlit
st.set_page_config(page_title="نموذج ذكاء اصطناعي احترافي", page_icon="🧠", layout="wide")

st.markdown("""
<style>
body { background-color: #f0f2f6; }
h1 { color: #0d6efd; }
.stButton>button { background-color: #0d6efd; color: white; font-size: 16px; padding: 0.5em 1em; }
.stTextArea>div>div>textarea, .stTextInput>div>input { font-size: 16px; }
.card { background-color: white; padding: 15px; border-radius: 10px; box-shadow: 0px 3px 10px rgba(0,0,0,0.1); margin-bottom: 10px; }
</style>
""", unsafe_allow_html=True)

st.title("🧠 نموذج ذكاء اصطناعي احترافي")
st.markdown("أدخل النص والسؤال، واختر الفئة، وسيقوم النموذج بالإجابة وحفظ كل شيء مع لوحة تحكم وإحصائيات.")

# إعداد قاعدة البيانات SQLite
conn = sqlite3.connect("qa_db.sqlite")
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS qa_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    context TEXT NOT NULL,
    answer TEXT NOT NULL,
    confidence REAL NOT NULL,
    category TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()

# إدخال النص والسؤال والفئة
context = st.text_area("📄 النص / السياق", "الذكاء الاصطناعي هو فرع من علوم الحاسوب.")
question = st.text_input("❓ السؤال", "ما هو الذكاء الاصطناعي؟")
category = st.selectbox("📚 اختر الفئة / الموضوع", ["عام", "الذكاء الاصطناعي", "الرياضيات", "العلوم", "اللغة", "أخرى"])

# الحصول على الإجابة
if st.button("احصل على الإجابة"):
    if context.strip() == "" or question.strip() == "":
        st.warning("يرجى إدخال النص والسؤال!")
    else:
        result = qa_pipeline(question=question, context=context)
        answer = result['answer']
        score = float(result['score'])

        st.markdown(f"""
        <div class="card">
        <h3>الإجابة:</h3>
        <p>{answer}</p>
        <small>درجة الثقة: {score:.2f}</small><br>
        <small>الفئة: {category}</small>
        </div>
        """, unsafe_allow_html=True)

        cursor.execute("""
        INSERT INTO qa_history (question, context, answer, confidence, category) 
        VALUES (?, ?, ?, ?, ?)
        """, (question, context, answer, score, category))
        conn.commit()
        st.toast("✅ تم حفظ السؤال والإجابة بنجاح!", icon="✅")

# لوحة تحكم المسؤول
st.sidebar.header("لوحة التحكم")
if st.sidebar.checkbox("📂 عرض الأسئلة والإجابات"):
    df = pd.read_sql_query("SELECT * FROM qa_history ORDER BY created_at DESC", conn)
    st.dataframe(df)
    # البحث حسب الكلمة أو الفئة
    search_term = st.text_input("🔍 ابحث في الأسئلة أو الإجابات")
    filter_category = st.selectbox("تصفية حسب الفئة", ["الكل"] + ["عام","الذكاء الاصطناعي","الرياضيات","العلوم","اللغة","أخرى"])
    filtered_df = df
    if search_term:
        filtered_df = df[df['question'].str.contains(search_term, case=False) | df['answer'].str.contains(search_term, case=False)]
    if filter_category != "الكل":
        filtered_df = filtered_df[filtered_df['category']==filter_category]
    st.dataframe(filtered_df)

    # حذف سؤال محدد
    delete_id = st.number_input("🗑️ حذف سؤال حسب ID", min_value=0, step=1)
    if st.button("حذف السؤال"):
        cursor.execute("DELETE FROM qa_history WHERE id=?", (delete_id,))
        conn.commit()
        st.success(f"تم حذف السؤال ID={delete_id}")

    # تصدير CSV و Excel
    csv = filtered_df.to_csv(index=False).encode('utf-8')
    st.download_button("⬇️ تصدير CSV", csv, "qa_history.csv", "text/csv")
    excel_file = "qa_history.xlsx"
    filtered_df.to_excel(excel_file, index=False)
    with open(excel_file,"rb") as file:
        st.download_button("⬇️ تصدير Excel", file, "qa_history.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

# الإحصائيات
if st.sidebar.checkbox("📊 الإحصائيات"):
    df = pd.read_sql_query("SELECT * FROM qa_history", conn)
    if not df.empty:
        st.subheader("عدد الأسئلة حسب الفئة")
        fig, ax = plt.subplots()
        sns.countplot(x='category', data=df, palette="Set2", ax=ax)
        st.pyplot(fig)

        st.subheader("أعلى 5 أسئلة حسب درجة الثقة")
        top5 = df.sort_values(by='confidence', ascending=False).head(5)
        st.dataframe(top5[['question','answer','confidence','category']])

        st.subheader("متوسط درجة الثقة لكل فئة")
        mean_conf = df.groupby('category')['confidence'].mean().reset_index()
        st.dataframe(mean_conf)

        # إنشاء تقرير PDF
        if st.button("📄 تصدير تقرير PDF"):
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", 'B', 16)
            pdf.cell(0, 10, "تقرير الأسئلة والإجابات", ln=True, align='C')
            pdf.ln(10)
            for index, row in df.iterrows():
                pdf.set_font("Arial", 'B', 12)
                pdf.multi_cell(0, 8, f"السؤال: {row['question']}")
                pdf.set_font("Arial", '', 12)
                pdf.multi_cell(0, 8, f"الإجابة: {row['answer']}")
                pdf.multi_cell(0, 8, f"درجة الثقة: {row['confidence']:.2f} | الفئة: {row['category']}")
                pdf.ln(5)
            pdf_file = "qa_report.pdf"
            pdf.output(pdf_file)
            with open(pdf_file, "rb") as file:
                st.download_button("⬇️ تحميل تقرير PDF", file, "qa_report.pdf", "application/pdf")

conn.close()